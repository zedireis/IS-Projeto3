create function add_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.modified = now();
    RETURN NEW;
END;
$$;

alter function add_timestamp() owner to postgres;

